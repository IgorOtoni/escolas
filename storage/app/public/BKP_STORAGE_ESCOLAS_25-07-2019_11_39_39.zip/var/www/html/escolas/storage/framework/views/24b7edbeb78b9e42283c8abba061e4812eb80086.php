<?php /* /var/www/html/escolas/resources/views/layouts/template2/confirmacaoDados.blade.php */ ?>
<?php $__env->startPush('script'); ?>

<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<!-- ##### About Us Area Start ##### -->
<div class="about-us-area about-page section-padding-100">
    <div class="container">
        <div class="row align-items-center justify-content-between">
            <div class="col-12 col-lg-12">
                <div class="about-content">
                    <h2>Confirmação</h2>
                    <p>Dados recebidos, entraremos em contato se for necessário, agradecemos pela atenção!</p>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- ##### About Us Area End ##### -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>